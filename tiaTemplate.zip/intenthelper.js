'use strict';

module.exports = {
	requestIntents : function(functionality) {
		if(IntentData.intentResponse.functionality != null) {
			return IntentData.intentResponse.functionality;
		}
		return "Sorry, no matches found.";
	}
};