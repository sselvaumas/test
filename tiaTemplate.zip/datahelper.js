'use strict';

module.exports = {
	requestNavigation : function(functionality) {
	  if(functionality.indexOf("investment performance")!==-1){
		return "You can navigate to Administration Tab and then investments and click on the View Investment performance.";
	  }
	},
	requestHelpContent : function(functionality) {
	 if(functionality!==null && functionality.replace(" ","").indexOf("siteusers")!==-1){
		return "I can send you the Reference series containing the Tips and Tricks for managing the users. Do you want me to send?";
	  }
	},
	sendEmail : function(email,functionality) {
	 if(email!==null){
		return "Thanks. Requested Content about " + functionality + " is sent to your email id " + email + ". Please let us know if you need anything else.";
	  }
	}
};
