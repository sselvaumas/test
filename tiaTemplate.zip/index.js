/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 * This sample shows how to create a Lambda function for handling Alexa Skill requests that:
 *
 * - Custom slot type: demonstrates using custom slot types to handle a finite set of known values
 *
 * Examples:
 * One-shot model:
 *  User: "Alexa, ask Minecraft Helper how to make paper."
 *  Alexa: "(reads back recipe for paper)"
 */

'use strict';

var AlexaSkill = require('./AlexaSkill'),
    datahelper = require('./datahelper');

var IntentData = require("./intent.json");
	
var APP_ID = 'amzn1.echo-sdk-ams.app.3b85054f-4582-4dd9-9b27-8f66a372c76d'; //replace with 'amzn1.echo-sdk-ams.app.[your-unique-value-here]';

/**
 * MySavingsHelper is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var MySavingsHelper = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
MySavingsHelper.prototype = Object.create(AlexaSkill.prototype);
MySavingsHelper.prototype.constructor = MySavingsHelper;

MySavingsHelper.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    var speechText = "Welcome to Tia Voice Assistant.To Start with, please tell me whether you are Participant or Plan Sponsor.";
    // If the user either does not reply to the welcome message or says something that is not
    // understood, they will be prompted again with this text.
    var repromptText = "For instructions on what you can say, please say help me.";
    response.ask(speechText, repromptText);
};

MySavingsHelper.prototype.intentHandlers = {
    "TiaHelpIntent": function (intent, session, response) {
        var userTypeSlot = intent.slots.UserType,
			userIdSlot = intent.slots.UserId,
			secSlot = intent.slots.SecurityAnswer,
			funcSlot = intent.slots.Functionality,
			reqSlot = intent.slots.RequestType,
			emailSlot = intent.slots.Email;
           
        if (userTypeSlot && userTypeSlot.value){
          	handleUserTypeDialogRequest(intent, session, response);
        }else if(userIdSlot && userIdSlot.value){
			handleUserIdDialogRequest(intent, session, response);
        }else if(secSlot && secSlot.value){
			handleSecurityAnswerDialogRequest(intent, session, response);
        }else if(reqSlot && reqSlot.value){
			handleRequestDialogRequest(intent, session, response);
        }else if(emailSlot && emailSlot.value){
			handleEmailDialogRequest(intent, session, response);
        }

      
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = "Goodbye";
        response.tell(speechOutput);
    },

    "AMAZON.HelpIntent": function (intent, session, response) {
        var speechText = "You can ask questions about Savings such as, what's the total savings for contribution percent of 4, or, you can say exit... Now, what can I help you with?";
        var repromptText = "You can say things like, what's the total savings for contribution percent of 4, or you can say exit... Now, what can I help you with?";
        var speechOutput = {
            speech: speechText,
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        var repromptOutput = {
            speech: repromptText,
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        response.ask(speechOutput, repromptOutput);
    }
};

function getUserTypeFromIntent(intent) {

    var userType = intent.slots.UserType;
	return userType;
}

function getUserIdFromIntent(intent) {

    var UserId = intent.slots.UserId;
	return UserId;
}

function getSecurityAnswerFromIntent(intent) {

    var SecurityAnswer = intent.slots.SecurityAnswer;
	return SecurityAnswer;
}

function getFunctionalityFromIntent(intent) {

    var Functionality = intent.slots.Functionality;
	return Functionality;
}

function getRequestTypeFromIntent(intent) {

    var RequestType = intent.slots.RequestType;
	return RequestType;
}

function getEmailFromIntent(intent) {

    var Email = intent.slots.Email;
	return Email;
}

/**
 * Handles the dialog step where the user provides a city
 */
function handleUserTypeDialogRequest(intent, session, response) {

    var userType = getUserTypeFromIntent(intent),
        repromptText,
        speechOutput;
         // set city in session and prompt for date
        session.attributes.usertype = userType;
        speechOutput = "Great. Can you tell me your userid?";
        repromptText = "Great. Can you tell me your userid?";
        response.ask(speechOutput, repromptText);
    }


function handleUserIdDialogRequest(intent, session, response) {

    var userId = getUserIdFromIntent(intent),
        repromptText,
        speechOutput;
         // set city in session and prompt for date
        session.attributes.userid = userId;
        speechOutput = "What is your mom's name?";
        repromptText = "What is your mom's name?";
        response.ask(speechOutput, repromptText);
    }


function handleSecurityAnswerDialogRequest(intent, session, response) {

    var securityAnswer = getSecurityAnswerFromIntent(intent),
        repromptText,
        speechOutput;
         // set city in session and prompt for date
        session.attributes.securityAnswer = securityAnswer;
        speechOutput = "Thanks,you are authenticated to access the Plan Sponsor Features. Now you can ask me questions like How can i view the Investment performance of my retirement plans.";
        repromptText = "Thanks,you are authenticated to access the Plan Sponsor Features. Now you can ask me questions like How can i view the Investment performance of my retirement plans.";
        response.ask(speechOutput, repromptText);
    }


function handleRequestDialogRequest(intent, session, response) {

    var requestType = getRequestTypeFromIntent(intent),
	    functionality = getFunctionalityFromIntent(intent),
        repromptText,
        speechOutput;
         // set city in session and prompt for date
        session.attributes.requestType = requestType;
		session.attributes.functionality = functionality;
		if(requestType.value.toLowerCase()==='view'){
			handleViewOutput(intent, session, response);
		}else if(requestType.value.toLowerCase()==='manage'){
			handleManageOutput(intent, session, response);
		}
    }
	
function handleEmailDialogRequest(intent, session, response) {

    var email = getEmailFromIntent(intent),
	    repromptText,
        speechOutput;
         // set city in session and prompt for date
        session.attributes.email = email;
		speechOutput = datahelper.sendEmail(session.attributes.email.value.toLowerCase());
        repromptText = "What else can I help with?";
        response.ask(speechOutput, repromptText);
    }
	
function handleViewOutput(intent, session, response){
	  var cardTitle = "You can navigate to",
            recipe = datahelper.requestNavigation(session.attributes.functionality.value.toLowerCase()),
            speechOutput,
            repromptOutput;
        if (recipe) {
            speechOutput = {
                speech: recipe,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.tellWithCard(speechOutput, cardTitle, recipe);
        } else {
            var speech;
            speech = "I'm sorry, I currently do not know the navigation for " + session.attributes.functionality.value.toLowerCase() + ". What else can I help with?";
            speechOutput = {
                speech: speech,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            repromptOutput = {
                speech: "What else can I help with?",
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.ask(speechOutput, repromptOutput);
        }
}

function handleManageOutput(intent, session, response){
	  var cardTitle = "I can send",
            recipe = datahelper.requestHelpContent(session.attributes.functionality.value.toLowerCase()),
            speechOutput,
            repromptOutput;
        if (recipe) {
            speechOutput = {
                speech: recipe,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.tellWithCard(speechOutput, cardTitle, recipe);
        } else {
            var speech;
            speech = "I'm sorry, I currently do not know the navigation for " + session.attributes.functionality.value.toLowerCase() + ". What else can I help with?";
            speechOutput = {
                speech: speech,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            repromptOutput = {
                speech: "What else can I help with?",
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.ask(speechOutput, repromptOutput);
        }
}


exports.handler = function (event, context) {
    var mySavingsHelper = new MySavingsHelper();
    mySavingsHelper.execute(event, context);
};
