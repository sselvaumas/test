package com.mlaas;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class TestFromWebApp {

	public static void main(String args[]) throws IOException {
		
		String comment = "test test test";
		
		CommentClassifier classify = new CommentClassifier("ol");
		
		String classification = classify.testComment(comment);
		
		System.out.println("the comment " + comment + " can be classified in category " + classification);
		
		List<String> comments = Arrays.asList("test test test", "your web design sucks!!", "customer representative was very helpful");
		
		List<String> categories = classify.classifyComments(comments);
		
		System.out.println(categories);

	}

}

