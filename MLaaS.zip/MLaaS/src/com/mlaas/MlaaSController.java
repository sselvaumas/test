package com.mlaas;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mlaas.model.Request;
import com.mlaas.model.Response;

@RestController
@RequestMapping(value="/api")
public class MlaaSController {
	
	@Autowired
	MlaaSClassifier mlaasclassifier;

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		List<HttpMessageConverter<?>> converters = restTemplate
				.getMessageConverters();
		for (HttpMessageConverter<?> converter : converters) {
			if (converter instanceof MappingJackson2HttpMessageConverter) {
				MappingJackson2HttpMessageConverter jsonConverter = (MappingJackson2HttpMessageConverter) converter;
				jsonConverter.setObjectMapper(new ObjectMapper());
				List<MediaType> supportedMediaTypes = new ArrayList<MediaType>();
				supportedMediaTypes.add(new MediaType("application", "json",
						MappingJackson2HttpMessageConverter.DEFAULT_CHARSET));
				supportedMediaTypes.add(new MediaType("text", "javascript",
						MappingJackson2HttpMessageConverter.DEFAULT_CHARSET));
				jsonConverter.setSupportedMediaTypes(supportedMediaTypes);
			}
		}
		return restTemplate;
	}
	
	@RequestMapping(value="/createModel",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Response createModel(@RequestBody Request request) throws IOException{
		Response response = new Response();
		//For Sake of demo, Lets assume
		//Model will created and unique id will be assigned, which can be used to access the classifier later by the consumer applications
		//For now, we are creating the same model
		mlaasclassifier.createClassifier("ol");
		return response;
	}
	
	@RequestMapping(value="/categorize",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Response categorize(@RequestBody Request request) throws IOException{
		Response response = new Response();
		mlaasclassifier.createClassifier("ol");
		response.setCategoryType(mlaasclassifier.testComment(request.getText()));
		return response;
	}

	
	@RequestMapping(value="/bulkCategorize",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Response bulkCategorize(@RequestBody Request request){
		Response response = new Response();
		return response;
	}



}
