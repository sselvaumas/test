package com.mlaas;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.generic.GenericRecord;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.hadoop.fs.Path;
import org.apache.spark.mllib.classification.LogisticRegressionModel;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.mllib.feature.HashingTF;

import parquet.avro.AvroReadSupport;
import parquet.hadoop.ParquetReader;

public class CommentClassifier {

	private static Map<Double, String> categoryMap = new HashMap<Double, String>();
	private static int numFeatures = 1000;
	private static int numClasses = 10;
	private static HashingTF hash = new HashingTF(1000);
	private LogisticRegressionModel model = null;

	@SuppressWarnings({ "unchecked", "unused" })
	public CommentClassifier(String name) throws IOException {

		categoryMap.put(1.0, "data");
		categoryMap.put(2.0, "customer service");
		categoryMap.put(3.0, "customer care");
		categoryMap.put(4.0, "feedback");
		categoryMap.put(5.0, "suggestion");
		categoryMap.put(6.0, "webdesign");
		categoryMap.put(7.0, "navigation");
		categoryMap.put(8.0, "submission");
		categoryMap.put(9.0, "other");

		String filePathString = "models/" + name + "/data/part-r-00001.parquet";
		Path filePath = new Path(filePathString);

		ParquetReader<GenericRecord> reader = ParquetReader.builder(
				new AvroReadSupport<GenericRecord>(), filePath).build();

		for (GenericRecord value = reader.read(); value != null; value = reader
				.read()) {
			GenericRecord record = (GenericRecord) value.get("weights");
			Double intercepts = (Double) value.get("intercept");
			List<Double> valueList = (List<Double>) record.get("values");
			Double[] valueArray = valueList
					.toArray(new Double[valueList.size()]);
			Vector weights = Vectors.dense(ArrayUtils.toPrimitive(valueArray));
			model = new LogisticRegressionModel(weights, intercepts,
					numFeatures, numClasses);
			// System.out.println(model.toString());
			break;
		}
		reader.close();
	}

	public String testComment(String inputComment)
			throws IOException {

		Vector input = tokenizeAndVectorize(inputComment);
		return categoryMap.get(model.predict(input));

	}
	
	public List<String> classifyComments(List<String> commentList) {
		
		List<String> categoryList = new ArrayList<String>();
		
		for (String comment: commentList) {
			Vector input = tokenizeAndVectorize(comment);
			categoryList.add(categoryMap.get(model.predict(input)));
		}
		
		return categoryList;
	}
	
	private Vector tokenizeAndVectorize(String comment) {
		
		String[] tokenizedTerms = comment.replaceAll("[\\W&&[^\\s]]", "")
				.split("\\W+"); // THIS WILL BE THE SAME TOKENIZING LOGIC USED
								// WHILE CREATING THE MODEL
		List<String> vecList = new ArrayList<String>();

		for (String term : tokenizedTerms) {
			vecList.add(term);
		}

		Vector input = hash.transform(vecList);
		
		return input;
	}

}
