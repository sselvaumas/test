package com.mlaas.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseHeader {
	
	private int status;
	
	@JsonProperty("QTime")
	private int qtime;
	
	public int getQtime() {
		return qtime;
	}

	public void setQtime(int qtime) {
		this.qtime = qtime;
	}

	private Params params;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}


	public Params getParams() {
		return params;
	}

	public void setParams(Params params) {
		this.params = params;
	}
	
}
