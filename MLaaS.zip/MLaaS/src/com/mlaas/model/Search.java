package com.mlaas.model;

public class Search {
	
	private String location;
	private String name;

	private String phone;
	private String query;
	private String state;
	public String getLocation() {
		return location;
	}
	public String getName() {
		return name;
	}
	public String getPhone() {
		return phone;
	}
	public String getQuery() {
		return query;
	}
	
	public String getState() {
		return state;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public void setState(String state) {
		this.state = state;
	}
}
