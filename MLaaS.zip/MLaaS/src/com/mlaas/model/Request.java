package com.mlaas.model;

import java.util.List;

public class Request {
	
	private String name;
	
	public String getName() {
		return name;
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String text;

	public void setName(String name) {
		this.name = name;
	}

	public List<Params> getTrainingData() {
		return trainingData;
	}

	public void setTrainingData(List<Params> trainingData) {
		this.trainingData = trainingData;
	}

	private List<Params> trainingData; 
	
}
