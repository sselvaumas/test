package com.mlaas.model;

import java.util.List;

public class Doc {
	
	private String _version_;
	
	private String anchor;

	private String answer;

	private String category;

	private String id;

	private List<String> keywords;

	private String module;
	
	private String question;
	
	private String sub_category;
	
	private String title;
	
	
	public String get_version_() {
		return _version_;
	}
	
	public String getAnchor() {
		return anchor;
	}


	public String getAnswer() {
		return answer;
	}

	public String getCategory() {
		return category;
	}

	public String getId() {
		return id;
	}

	public List<String> getKeywords() {
		return keywords;
	}

	public String getModule() {
		return module;
	}

	public String getQuestion() {
		return question;
	}

	public String getSub_category() {
		return sub_category;
	}

	public String getTitle() {
		return title;
	}

	public void set_version_(String _version_) {
		this._version_ = _version_;
	}

	public void setAnchor(String anchor) {
		this.anchor = anchor;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public void setSub_category(String sub_category) {
		this.sub_category = sub_category;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
