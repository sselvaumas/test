package com.mlaas.model;

import java.util.List;

public class Response {
	
	private List<Doc> docs;
	
	private String emotion;
	
	private int numFound;
	
	private Params params;
	
	private String response;
	
	private int start;
	
	private String categoryType;

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public List<Doc> getDocs() {
		return docs;
	}

	public String getEmotion() {
		return emotion;
	}

	public int getNumFound() {
		return numFound;
	}

	public Params getParams() {
		return params;
	}

	public String getResponse() {
		return response;
	}

	public int getStart() {
		return start;
	}

	public void setDocs(List<Doc> docs) {
		this.docs = docs;
	}

	public void setEmotion(String emotion) {
		this.emotion = emotion;
	}

	public void setNumFound(int numFound) {
		this.numFound = numFound;
	}

	public void setParams(Params params) {
		this.params = params;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public void setStart(int start) {
		this.start = start;
	}

	
	
}
