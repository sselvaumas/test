package com.mlaas.model;

public class SearchResponse {
	
	private Response response;
	
	private ResponseHeader responseHeader;

	public Response getResponse() {
		return response;
	}

	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	public void setResponse(Response response) {
		this.response = response;
	}

	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}
}
