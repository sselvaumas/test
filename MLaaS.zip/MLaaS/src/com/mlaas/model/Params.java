package com.mlaas.model;

public class Params {
	
	private String text;
	
	private String classification;
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	private String indent;
	
	private String q;

	private String rows;

	private String wt;

	public String getIndent() {
		return indent;
	}

	public String getQ() {
		return q;
	}

	public String getRows() {
		return rows;
	}

	public String getWt() {
		return wt;
	}

	public void setIndent(String indent) {
		this.indent = indent;
	}

	public void setQ(String q) {
		this.q = q;
	}
	
	public void setRows(String rows) {
		this.rows = rows;
	}
	
	public void setWt(String wt) {
		this.wt = wt;
	}
	
}
