angular.module('mlaasApp.controllers',[]
).controller('ModelListController',function($scope,$state,popupService,$window,Model,$http){

    $scope.models=Model.query();

	$scope.deleteModel=function(){
		if(popupService.showPopup('Really delete this?')){
			$scope.model.$delete(function(){
				$state.go('models');
			});
        }
    }
	
}).controller('ModelDeleteController',function($scope,$stateParams,Model){

    $scope.model=new Model();

    

}).controller('ModelViewController',function($scope,$stateParams,Model){

    $scope.model=Model.get({id:$stateParams.id});

}).controller('ModelTestController',function($scope,$stateParams,Model,$http){

    $scope.model=Model.get({id:$stateParams.id});
    $scope.testClassify=function(){
    	var req = {
		 method: 'POST',
		 url: 'mlaas/api/categorize',
		 headers: {
		   'Content-Type': 'application/json'
		 },
		 data: { text: $scope.texttoclassify }
		}
    	$http(req).success(function (data, status, headers, config) {
            console.log(data);
            $scope.category = data.categoryType;
        })
        .error(function (data, status, header, config) {
           console.log('error');
        });
    }
    
}).controller('ModelCreateController',function($scope,$state,$stateParams,Model,$http){

    $scope.model=new Model();
    
    $scope.addModel=function(){
        /*$scope.model.$save(function(){
            $state.go('models');
        });*/
    	var req = {
		 method: 'POST',
		 url: 'mlaas/api/createModel',
		 headers: {
		   'Content-Type': 'application/json'
		 },
		 data: { name: $scope.modelname }
		}
    	$http(req).success(function (data, status, headers, config) {
            console.log('data');
        })
        .error(function (data, status, header, config) {
           console.log('error');
        });
    }

}).controller('ModelEditController',function($scope,$state,$stateParams,Model){

    $scope.updateModel=function(){
        $scope.model.$update(function(){
            $state.go('models');
        });
    };

    $scope.loadModel=function(){
        $scope.model=Model.get({id:$stateParams.id});
    };

    $scope.loadModel();
});