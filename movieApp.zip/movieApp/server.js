var express = require('express');
var app = express();
var path = require('path');

app.use('/css',express.static('css'));
app.use('/images',express.static('images'));
app.use('/js',express.static('js'));
app.use('/lib',express.static('lib'));
app.use('/partials',express.static('partials'));
app.use('/stylesheets',express.static('stylesheets'));

// viewed at http://localhost:8080
app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/index.html'));
});

app.listen(8080); 